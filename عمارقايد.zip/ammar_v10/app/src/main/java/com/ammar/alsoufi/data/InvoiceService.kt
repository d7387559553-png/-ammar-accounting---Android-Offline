package com.ammar.alsoufi.data

import android.database.sqlite.SQLiteDatabase

data class SaleResult(val invoiceId: Long, val total: Long, val remaining: Long)

/** Core invoice operations. Each invoice, stock movement, and agent balance change is atomic. */
class InvoiceService(private val db: AccountingDbHelper) {
    fun recordSale(
        number: String,
        productId: Long,
        quantity: Double,
        unitPrice: Long,
        paid: Long,
        agentId: Long? = null
    ): SaleResult = recordInvoice(number, productId, quantity, unitPrice, paid, agentId, "SALE")

    fun recordPurchase(
        number: String,
        productId: Long,
        quantity: Double,
        unitPrice: Long,
        paid: Long,
        agentId: Long? = null
    ): SaleResult = recordInvoice(number, productId, quantity, unitPrice, paid, agentId, "PURCHASE")

    private fun recordInvoice(
        number: String, productId: Long, quantity: Double, unitPrice: Long,
        paid: Long, agentId: Long?, type: String
    ): SaleResult {
        require(number.isNotBlank()) { "رقم الفاتورة مطلوب" }
        require(quantity > 0.0 && quantity.isFinite()) { "الكمية يجب أن تكون أكبر من صفر" }
        require(unitPrice >= 0L && paid >= 0L) { "السعر والمدفوع لا يمكن أن يكونا سالبين" }
        val total = (quantity * unitPrice).toLong()
        require(paid <= total) { "المدفوع لا يمكن أن يتجاوز إجمالي الفاتورة" }
        val sql = db.writableDatabase
        sql.beginTransaction()
        try {
            if (type == "SALE") {
                sql.rawQuery("SELECT quantity FROM products WHERE id=?", arrayOf(productId.toString())).use {
                    require(it.moveToFirst()) { "الصنف غير موجود" }
                    require(it.getDouble(0) >= quantity) { "الكمية المتوفرة في المخزون غير كافية" }
                }
            } else {
                sql.rawQuery("SELECT id FROM products WHERE id=?", arrayOf(productId.toString())).use {
                    require(it.moveToFirst()) { "الصنف غير موجود" }
                }
            }
            val id = db.addInvoice(number, type, null, agentId, total, paid)
            require(id > 0L) { "تعذر حفظ الفاتورة" }
            db.addInvoiceLine(id, productId, quantity, unitPrice)
            if (type == "SALE") db.decreaseProduct(productId, quantity)
            else db.increaseProduct(productId, quantity)
            if (agentId != null && paid < total) {
                // Positive balance means the agent is owed money for a sale, or owes for a purchase.
                val delta = total - paid
                db.updateAgentBalance(agentId, if (type == "SALE") delta else -delta)
            }
            sql.setTransactionSuccessful()
            return SaleResult(id, total, total - paid)
        } finally {
            sql.endTransaction()
        }
    }
}
