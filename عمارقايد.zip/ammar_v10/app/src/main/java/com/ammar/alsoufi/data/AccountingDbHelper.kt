package com.ammar.alsoufi.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AccountingDbHelper(context: Context) : SQLiteOpenHelper(context, "ammar_alsoufi.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE agents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, phone TEXT, type TEXT NOT NULL,
            commission REAL NOT NULL DEFAULT 0, balance INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, barcode TEXT, quantity REAL NOT NULL DEFAULT 0,
            purchase_price INTEGER NOT NULL DEFAULT 0, sale_price INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE invoices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            number TEXT NOT NULL, type TEXT NOT NULL,
            party_id INTEGER, agent_id INTEGER,
            total INTEGER NOT NULL, paid INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE cash_movements(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL, amount INTEGER NOT NULL,
            party_name TEXT, note TEXT, created_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE invoice_lines(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity REAL NOT NULL CHECK(quantity > 0),
            unit_price INTEGER NOT NULL CHECK(unit_price >= 0),
            line_total INTEGER NOT NULL CHECK(line_total >= 0),
            FOREIGN KEY(invoice_id) REFERENCES invoices(id),
            FOREIGN KEY(product_id) REFERENCES products(id))""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Keep existing user data while ensuring invoice lines exist on all upgraded installs.
        db.execSQL("""CREATE TABLE IF NOT EXISTS invoice_lines(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity REAL NOT NULL CHECK(quantity > 0),
            unit_price INTEGER NOT NULL CHECK(unit_price >= 0),
            line_total INTEGER NOT NULL CHECK(line_total >= 0),
            FOREIGN KEY(invoice_id) REFERENCES invoices(id),
            FOREIGN KEY(product_id) REFERENCES products(id))""")
    }

    fun addAgent(name:String, phone:String, type:String, commission:Double):Long =
        writableDatabase.insert("agents",null,ContentValues().apply{
            put("name",name); put("phone",phone); put("type",type); put("commission",commission)
        })

    fun addProduct(name:String, barcode:String, qty:Double, purchase:Long, sale:Long):Long =
        writableDatabase.insert("products",null,ContentValues().apply{
            put("name",name); put("barcode",barcode); put("quantity",qty)
            put("purchase_price",purchase); put("sale_price",sale)
        })

    fun addInvoice(number:String,type:String,partyId:Long?,agentId:Long?,total:Long,paid:Long):Long =
        writableDatabase.insert("invoices",null,ContentValues().apply{
            put("number",number); put("type",type); partyId?.let{put("party_id",it)}
            agentId?.let{put("agent_id",it)}; put("total",total); put("paid",paid)
            put("created_at",System.currentTimeMillis())
        })

    fun addCash(type:String,amount:Long,party:String,note:String):Long =
        writableDatabase.insert("cash_movements",null,ContentValues().apply{
            put("type",type); put("amount",amount); put("party_name",party); put("note",note)
            put("created_at",System.currentTimeMillis())
        })



    fun recordReturn(invoiceId:Long, productId:Long, quantity:Double, salePrice:Long, purchaseReturn:Boolean) {
        val type = if (purchaseReturn) "PURCHASE_RETURN" else "SALE_RETURN"
        val total = (quantity * salePrice).toLong()
        val id = writableDatabase.insert("invoices",null,ContentValues().apply{
            put("number","RET-$invoiceId-${System.currentTimeMillis()}")
            put("type",type); put("total",total); put("paid",0)
            put("created_at",System.currentTimeMillis())
        })
        addInvoiceLine(id,productId,quantity,salePrice)
        if (purchaseReturn) decreaseProduct(productId,quantity) else increaseProduct(productId,quantity)
    }

    fun agentBalance(agentId:Long):Long {
        readableDatabase.rawQuery(
            "SELECT COALESCE(balance,0) FROM agents WHERE id=?",
            arrayOf(agentId.toString())
        ).use { return if(it.moveToFirst()) it.getLong(0) else 0 }
    }

    fun totalSales():Long =
        sumWhere("invoices","total","type='SALE'")
    fun totalPurchases():Long =
        sumWhere("invoices","total","type='PURCHASE'")
    fun totalSaleReturns():Long =
        sumWhere("invoices","total","type='SALE_RETURN'")
    fun totalPurchaseReturns():Long =
        sumWhere("invoices","total","type='PURCHASE_RETURN'")

    private fun sumWhere(table:String,column:String,where:String):Long {
        readableDatabase.rawQuery("SELECT COALESCE(SUM($column),0) FROM $table WHERE $where",null).use {
            return if(it.moveToFirst()) it.getLong(0) else 0
        }
    }

    fun addInvoiceLine(invoiceId:Long, productId:Long, quantity:Double, unitPrice:Long):Long =
        writableDatabase.insert("invoice_lines",null,ContentValues().apply{
            put("invoice_id",invoiceId); put("product_id",productId)
            put("quantity",quantity); put("unit_price",unitPrice)
            put("line_total",(quantity*unitPrice).toLong())
        })

    fun decreaseProduct(productId:Long, quantity:Double) {
        writableDatabase.execSQL("UPDATE products SET quantity = quantity - ? WHERE id = ?",
            arrayOf(quantity, productId))
    }

    fun increaseProduct(productId:Long, quantity:Double) {
        writableDatabase.execSQL("UPDATE products SET quantity = quantity + ? WHERE id = ?",
            arrayOf(quantity, productId))
    }

    fun updateAgentBalance(agentId:Long, delta:Long) {
        writableDatabase.execSQL("UPDATE agents SET balance = balance + ? WHERE id = ?",
            arrayOf(delta, agentId))
    }

    fun getRemaining(invoiceId:Long):Long {
        readableDatabase.rawQuery("SELECT total-paid FROM invoices WHERE id=?",
            arrayOf(invoiceId.toString())).use { return if(it.moveToFirst()) it.getLong(0) else 0 }
    }

    fun count(table:String):Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM $table",null).use {
            return if(it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun sum(table:String,column:String):Long {
        readableDatabase.rawQuery("SELECT COALESCE(SUM($column),0) FROM $table",null).use {
            return if(it.moveToFirst()) it.getLong(0) else 0
        }
    }
}
